package com.example.bmi; // 声明源码所在包，供同包类型引用。

import org.json.JSONArray; // 引入 JSONArray 类型供本文件使用。
import org.json.JSONException; // 引入 JSONException 类型供本文件使用。
import org.json.JSONObject; // 引入 JSONObject 类型供本文件使用。
import java.io.BufferedReader; // 引入 BufferedReader 类型供本文件使用。
import java.io.IOException; // 引入 IOException 类型供本文件使用。
import java.io.InputStreamReader; // 引入 InputStreamReader 类型供本文件使用。
import java.io.OutputStream; // 引入 OutputStream 类型供本文件使用。
import java.net.HttpURLConnection; // 引入 HttpURLConnection 类型供本文件使用。
import java.net.URL; // 引入 URL 类型供本文件使用。
import java.nio.charset.StandardCharsets; // 引入 StandardCharsets 类型供本文件使用。
import java.util.Locale; // 引入 Locale 类型供本文件使用。

public class DeepSeekClient { // 封装服务请求及回复解析。
    public static class ApiException extends IOException { // 在网络异常中携带服务状态码。
        public final int status; // 供调用方读取 HTTP 状态。
        ApiException(int status) { // 构造带状态码的异常。
            super("API request failed"); // 为父类设置通用错误说明。
            this.status = status; // 保存具体状态供界面分类处理。
        } // 结束当前代码块。
    } // 结束当前代码块。

    public String getAdvice(String apiKey, double bmi, int age, String gender, // 接收认证信息和 BMI 资料。
                            String category, boolean chinese) throws IOException, JSONException { // 声明语言参数及调用方需要处理的两类错误。
        URL url = new URL("https://api.deepseek.com/chat/completions"); // 指定服务请求端点。
        HttpURLConnection connection = (HttpURLConnection) url.openConnection(); // 打开 HTTP 连接对象。
        connection.setRequestMethod("POST"); // 请求采用 POST。
        connection.setConnectTimeout(15000); // 限制建立连接的等待时间为十五秒。
        connection.setReadTimeout(60000); // 读取响应最多等待六十秒。
        connection.setInstanceFollowRedirects(false); // 关闭本连接的自动跳转。
        connection.setDoOutput(true); // 允许写入请求正文。
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8"); // 声明正文编码和 JSON 内容类型。
        connection.setRequestProperty("Authorization", "Bearer " + apiKey); // 按 Bearer 方案设置本次请求的认证头。
        try { // 在这里执行可能抛出异常的操作。
            JSONObject request = buildRequest(bmi, age, gender, category, chinese); // 先把资料组织为结构化请求。
            try (OutputStream output = connection.getOutputStream()) { // 打开输出流，离开作用域自动关闭。
                output.write(request.toString().getBytes(StandardCharsets.UTF_8)); // 以 UTF-8 编码发送 JSON。
            } // 结束当前代码块。
            int status = connection.getResponseCode(); // 读取服务器实际返回的状态。
            if (status != 200) throw new ApiException(status); // 将非成功状态转换为专用异常。
            StringBuilder body = new StringBuilder(); // 建立累积响应文本的缓冲区。
            try (BufferedReader reader = new BufferedReader(new InputStreamReader( // 用自动关闭的文本读取器接收返回内容。
                    connection.getInputStream(), StandardCharsets.UTF_8))) { // 以 UTF-8 解码响应输入流。
                String line; // 临时保存所读的一行文本。
                while ((line = reader.readLine()) != null) body.append(line); // 读到流结束，把各行追加为完整响应。
            } // 结束当前代码块。
            return parseReply(body.toString()); // 把完整响应交给解析函数。
        } finally { // 无论成功或异常均执行清理。
            connection.disconnect(); // 关闭连接并释放资源。
        } // 结束当前代码块。
    } // 结束当前代码块。

    static JSONObject buildRequest(double bmi, int age, String gender, String category, // 从 BMI 和用户资料构造 JSON 请求体。
                                   boolean chinese) throws JSONException { // 按语言配置提示，允许上层处理 JSON 错误。
        String language = chinese ? "Reply only in Simplified Chinese, in no more than 140 Chinese characters." // 中文界面请求短中文回复。
                : "Reply only in English, in no more than 90 words."; // 英文界面使用对应长度要求。
        String system = "Give 3 short, practical, age-appropriate suggestions about general diet and activity. " // 定义服务输出的建议主题和条数。
                + "Use plain text without markdown. " + language // 要求纯文本，并拼接语言要求。
                + " Use the supplied age-specific BMI category; do not reclassify children using adult cutoffs. " // 要求采用已计算的年龄分组。
                + "BMI is a screening measure, not a diagnosis. Do not prescribe medicines, calorie targets " // 设置回复的医学表述边界。
                + "or rapid weight loss. For minors suggest family or clinician support when appropriate. " // 继续限定回复内容及对未成年人的表述。
                + "For a severe category advise consulting a clinician."; // 给严重分类加入就医建议的提示要求。
        String profile = String.format(Locale.US, "BMI: %.2f; age: %d years; gender: %s; category: %s.", // 使用固定区域格式组织传出的资料。
                bmi, age, gender, category); // 按模板顺序填入四个参数。
        JSONArray messages = new JSONArray() // 建立有序的消息数组。
                .put(new JSONObject().put("role", "system").put("content", system)) // 加入系统角色及其指令文本。
                .put(new JSONObject().put("role", "user").put("content", profile)); // 加入用户角色和本次资料。
        return new JSONObject().put("model", "deepseek-flash") // 在请求对象写入本作业使用的模型标识。
                .put("messages", messages).put("stream", false).put("max_tokens", 500) // 设置消息、关闭流式传输并限制输出。
                .put("thinking", new JSONObject().put("type", "disabled")); // 补充原作业的推理选项。
    } // 结束当前代码块。

    static String parseReply(String body) throws JSONException { // 解析已收到的一份 JSON 正文。
        JSONObject choice = new JSONObject(body).getJSONArray("choices").getJSONObject(0); // 从候选列表取出第一项。
        if (!"stop".equals(choice.optString("finish_reason"))) { // 检查返回是否正常结束。
            throw new JSONException("Incomplete reply"); // 截断或非预期终止时报告解析错误。
        } // 结束当前代码块。
        String text = choice.getJSONObject("message").getString("content").trim(); // 读取回复文字并去除首尾空白。
        if (text.isEmpty()) throw new JSONException("Empty reply"); // 拒绝没有实际正文的回复。
        return text; // 把校验后的正文返回给上层。
    } // 结束当前代码块。
} // 结束当前代码块。
