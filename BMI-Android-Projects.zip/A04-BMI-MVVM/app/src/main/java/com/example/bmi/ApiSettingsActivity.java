package com.example.bmi; // 声明源码所在包，供同包类型引用。

import android.content.Context; // 引入 Context 类型供本文件使用。
import android.os.Bundle; // 引入 Bundle 类型供本文件使用。
import android.view.MenuItem; // 引入 MenuItem 类型供本文件使用。
import android.view.WindowManager; // 引入 WindowManager 类型供本文件使用。
import android.widget.EditText; // 引入 EditText 类型供本文件使用。
import android.widget.Toast; // 引入 Toast 类型供本文件使用。
import androidx.appcompat.app.AppCompatActivity; // 引入 AppCompatActivity 类型供本文件使用。

public class ApiSettingsActivity extends AppCompatActivity { // 定义应用的服务配置页面。
    static String getApiKey(Context context) { // 集中读取本机保存的凭据。
        return context.getSharedPreferences("deepseek", MODE_PRIVATE).getString("api_key", ""); // 读取私有偏好设置，缺失时返回空字符串。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    protected void onCreate(Bundle savedInstanceState) { // 页面创建时绑定布局和交互逻辑。
        super.onCreate(savedInstanceState); // 先交给父类初始化。
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE); // 请求系统限制此窗口的截屏等捕获操作。
        setContentView(R.layout.activity_api_settings); // 加载配置页面布局。
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 存在操作栏时提供返回入口。
        EditText input = findViewById(R.id.api_key_input); // 绑定用于输入凭据的文本框。
        if (!getApiKey(this).isEmpty()) input.setHint(R.string.key_saved_hint); // 有保存值时仅给出提示，不回显内容。
        findViewById(R.id.save_key_button).setOnClickListener(view -> { // 绑定保存按钮。
            String key = input.getText().toString().trim(); // 读取输入并清除首尾空白。
            if (key.isEmpty() && getApiKey(this).isEmpty()) { // 没有新值也没有旧值时需要提示。
                input.setError(getString(R.string.key_required)); // 在输入框旁标出必填。
                return; // 在此结束当前方法或回调。
            } // 结束当前代码块。
            if (!key.isEmpty()) getSharedPreferences("deepseek", MODE_PRIVATE) // 只有输入新值时才覆盖偏好设置。
                    .edit().putString("api_key", key).apply(); // 保存到本应用偏好并异步写盘。
            input.setText(""); // 保存后清空输入控件中的内容。
            Toast.makeText(this, R.string.key_saved, Toast.LENGTH_SHORT).show(); // 短暂显示保存成功提示。
            finish(); // 关闭当前页面，返回上一层。
        }); // 结束回调并完成注册或提交。
        findViewById(R.id.remove_key_button).setOnClickListener(view -> { // 绑定移除按钮。
            getSharedPreferences("deepseek", MODE_PRIVATE).edit().remove("api_key").apply(); // 删除对应键并提交变更。
            input.setText(""); // 保存后清空输入控件中的内容。
            Toast.makeText(this, R.string.key_removed, Toast.LENGTH_SHORT).show(); // 提示已移除。
            finish(); // 关闭当前页面，返回上一层。
        }); // 结束回调并完成注册或提交。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    public boolean onOptionsItemSelected(MenuItem item) { // 接收顶栏菜单点击事件。
        if (item.getItemId() == android.R.id.home) { // 检查操作栏的返回动作。
            finish(); // 关闭当前页面，返回上一层。
            return true; // 返回真，告知调用方本次处理成功。
        } // 结束当前代码块。
        return super.onOptionsItemSelected(item); // 其它条目回退给父类处理。
    } // 结束当前代码块。
} // 结束当前代码块。
