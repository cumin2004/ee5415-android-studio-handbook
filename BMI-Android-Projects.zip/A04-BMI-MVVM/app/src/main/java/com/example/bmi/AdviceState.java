package com.example.bmi; // 声明源码所在包，供同包类型引用。

public final class AdviceState { // 一次请求的界面状态包含进度、文字和资源消息。
    public final boolean loading; // 记录请求是否进行中。
    public final String text; // 成功时携带返回正文。
    public final int message; // 缺少凭据或发生错误时保存对应资源编号。

    public AdviceState(boolean loading, String text, int message) { // 创建一个完整的状态快照。
        this.loading = loading; // 保存加载标志。
        this.text = text; // 保存可显示的正文。
        this.message = message; // 保存提示文字的资源编号。
    } // 结束当前代码块。
} // 结束当前代码块。
