package com.example.bmi; // 声明源码所在包，供同包类型引用。

import android.os.Handler; // 引入 Handler 类型供本文件使用。
import android.os.Looper; // 引入 Looper 类型供本文件使用。
import androidx.lifecycle.LiveData; // 引入 LiveData 类型供本文件使用。
import androidx.lifecycle.MutableLiveData; // 引入 MutableLiveData 类型供本文件使用。
import androidx.lifecycle.ViewModel; // 引入 ViewModel 类型供本文件使用。
import org.json.JSONException; // 引入 JSONException 类型供本文件使用。
import java.io.IOException; // 引入 IOException 类型供本文件使用。
import java.net.SocketTimeoutException; // 引入 SocketTimeoutException 类型供本文件使用。
import java.util.concurrent.ExecutorService; // 引入 ExecutorService 类型供本文件使用。
import java.util.concurrent.Executors; // 引入 Executors 类型供本文件使用。
import java.util.concurrent.Future; // 引入 Future 类型供本文件使用。

public class AdviceViewModel extends ViewModel { // 协调后台请求、生命周期和主线程的界面状态。
    private final DeepSeekClient client = new DeepSeekClient(); // 持有封装 HTTP 与 JSON 的客户端。
    private final ExecutorService executor = Executors.newSingleThreadExecutor(); // 使用单线程执行器，避免在主线程做网络请求。
    private final MutableLiveData<AdviceState> state = new MutableLiveData<>(); // 通过 LiveData 把请求状态交给报告页。
    private final Handler mainThread = new Handler(Looper.getMainLooper()); // 把后台结果切回主线程发布。
    private Future<?> task; // 保存可取消的后台任务句柄。
    private String signature = ""; // 记录上一次请求特征，以便去重。
    private volatile int requestId; // 维护线程间可见的请求序号。

    public LiveData<AdviceState> getState() { return state; } // 外部观察状态，内部负责修改。

    public void load(String key, double bmi, int age, String gender, String category, // 接收计算资料及当前认证信息。
                     boolean chinese, boolean retry) { // 补充目标语言和是否强制重试两个参数。
        String next = key + "|" + bmi + "|" + age + "|" + gender + "|" + category + "|" + chinese; // 组合输入和语言来识别相同的请求。
        if (!retry && signature.equals(next)) return; // 普通加载跳过重复请求，手动重试可继续。
        signature = next; // 更新最近请求的标识。
        int id = ++requestId; // 递增并捕获本次请求序号。
        if (task != null) task.cancel(true); // 已有任务时尝试取消，减少多余工作。
        if (key.isEmpty()) { // 检查是否缺少认证信息。
            state.setValue(new AdviceState(false, null, R.string.missing_key)); // 发布缺少认证信息的状态。
            return; // 在此结束当前方法或回调。
        } // 结束当前代码块。
        state.setValue(new AdviceState(true, null, R.string.loading)); // 先显示加载状态。
        task = executor.submit(() -> { // 在后台线程开始请求，保存可取消句柄。
            AdviceState result; // 为成功或失败状态预留变量。
            try { // 在这里执行可能抛出异常的操作。
                String text = client.getAdvice(key, bmi, age, gender, category, chinese); // 向客户端传入本次计算资料取得建议文字。
                result = new AdviceState(false, text, 0); // 将成功正文包装为完成状态。
            } catch (DeepSeekClient.ApiException error) { // 处理服务端返回的非成功状态码。
                int message = error.status == 401 || error.status == 403 ? R.string.auth_error // 认证或权限错误映射到专用提示。
                        : error.status == 402 ? R.string.balance_error // 余额不足映射到对应提示。
                        : error.status == 429 ? R.string.rate_error : R.string.service_error; // 区分限流与其它服务错误。
                result = new AdviceState(false, null, message); // 根据刚选择的资源形成失败状态。
            } catch (SocketTimeoutException error) { // 独立捕获网络超时。
                result = new AdviceState(false, null, R.string.timeout_error); // 选择超时的界面文案。
            } catch (JSONException error) { // 捕获 JSON 格式或回复结构异常。
                result = new AdviceState(false, null, R.string.invalid_reply); // 提示服务返回内容无效。
            } catch (IOException error) { // 捕获其余网络读写错误。
                result = new AdviceState(false, null, R.string.request_error); // 显示通用网络错误文字。
            } // 结束当前代码块。
            AdviceState completed = result; // 固定本次结果供主线程回调捕获。
            mainThread.post(() -> { // 将更新切换至主线程。
                if (id == requestId) state.setValue(completed); // 只接受最新请求，避免旧返回覆盖新结果。
            }); // 结束回调并完成注册或提交。
        }); // 结束回调并完成注册或提交。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    protected void onCleared() { // ViewModel 被销毁时清理后台资源。
        ++requestId; // 让尚未完成的旧回调失效。
        if (task != null) task.cancel(true); // 已有任务时尝试取消，减少多余工作。
        executor.shutdownNow(); // 请求停止线程池。
    } // 结束当前代码块。
} // 结束当前代码块。
