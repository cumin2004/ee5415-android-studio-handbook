plugins { id("com.android.application") } // 应用或声明 Android 构建插件。
android { // 进入安卓模块设置。
    namespace = "com.example.bmi" // 生成资源类的命名空间。
    compileSdk { version = release(33) } // 选择编译时可用的安卓接口。
    defaultConfig { // 统一配置应用标识与支持版本。
        applicationId = "com.example.bmi.mvvm" // 指定安装包在设备上的唯一标识。
        minSdk = 21 // 限制最低可安装系统版本。
        targetSdk = 33 // 指定适配的目标接口版本。
        versionCode = 1 // 定义整数版本号。
        versionName = "1.0" // 定义可读版本名。
    } // 结束当前构建配置块。
    compileOptions { // 设置 Java 编译选项。
        sourceCompatibility = JavaVersion.VERSION_11 // 规定源码语言级别。
        targetCompatibility = JavaVersion.VERSION_11 // 规定目标字节码版本。
    } // 结束当前构建配置块。
} // 结束当前构建配置块。

dependencies { // 列出模块用到的依赖。
    implementation("androidx.appcompat:appcompat:1.6.1") // 加入此行指定的库供应用编译与运行。
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.6.1") // 加入此行指定的库供应用编译与运行。
    implementation("androidx.lifecycle:lifecycle-livedata:2.6.1") // 加入此行指定的库供应用编译与运行。
} // 结束当前构建配置块。
