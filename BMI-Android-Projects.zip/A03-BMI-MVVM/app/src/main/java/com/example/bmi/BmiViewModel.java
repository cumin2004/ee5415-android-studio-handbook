package com.example.bmi; // 声明源码所在包，供同包类型引用。

import androidx.lifecycle.LiveData; // 引入 LiveData 类型供本文件使用。
import androidx.lifecycle.MutableLiveData; // 引入 MutableLiveData 类型供本文件使用。
import androidx.lifecycle.ViewModel; // 引入 ViewModel 类型供本文件使用。

public class BmiViewModel extends ViewModel { // 用 ViewModel 保存和发布计算结果。
    private final BmiModel model = new BmiModel(); // 持有负责校验与计算的模型。
    private final MutableLiveData<BmiResult> result = new MutableLiveData<>(); // 内部可修改的 LiveData 承载输出。
    public LiveData<BmiResult> getResult() { return result; } // 页面取得只读接口来订阅结果。
    public void calculate(String height, String weight, String age, String gender) { // 接收页面交来的原始表单数据。
        result.setValue(model.calculate(height, weight, age, gender)); // 模型算完后发布结果，触发观察者。
    } // 结束当前代码块。
    public void clearResult() { result.setValue(null); } // 清空已处理结果，防止界面重建时重复打开报告。
} // 结束当前代码块。
