package com.example.bmi; // 声明源码所在包，供同包类型引用。

import android.content.Intent; // 引入 Intent 类型供本文件使用。
import android.net.Uri; // 引入 Uri 类型供本文件使用。
import android.os.Bundle; // 引入 Bundle 类型供本文件使用。
import android.view.ContextMenu; // 引入 ContextMenu 类型供本文件使用。
import android.view.Menu; // 引入 Menu 类型供本文件使用。
import android.view.MenuItem; // 引入 MenuItem 类型供本文件使用。
import android.view.View; // 引入 View 类型供本文件使用。
import android.widget.EditText; // 引入 EditText 类型供本文件使用。
import android.widget.RadioGroup; // 引入 RadioGroup 类型供本文件使用。
import android.widget.TextView; // 引入 TextView 类型供本文件使用。
import androidx.appcompat.app.AlertDialog; // 引入 AlertDialog 类型供本文件使用。
import androidx.appcompat.app.AppCompatActivity; // 引入 AppCompatActivity 类型供本文件使用。
import androidx.lifecycle.ViewModelProvider; // 引入 ViewModelProvider 类型供本文件使用。
public class MainActivity extends AppCompatActivity  { // 定义 MVI 版输入页。
    private EditText heightInput, weightInput, ageInput; // 持有三个输入框，供按钮事件取值。
    private RadioGroup genderGroup; // 持有性别单选组，便于读取当前选中的按钮。
    private TextView genderError; // 持有性别错误提示文字，未选时显示。
    private BmiViewModel viewModel; // 保存当前页所属的 ViewModel。
    @Override // 覆盖父类或接口声明的方法。
    protected void onCreate(Bundle savedInstanceState) { // 页面创建时绑定布局和交互逻辑。
        super.onCreate(savedInstanceState); // 先交给父类初始化。
        setContentView(R.layout.activity_main); // 加载主页面布局。控件必须等布局加载后才能查找。
        heightInput = findViewById(R.id.height_input); // 用 XML 中的身高 ID 绑定输入框。
        weightInput = findViewById(R.id.weight_input); // 用 XML 中的体重 ID 绑定输入框。
        ageInput = findViewById(R.id.age_input); // 用 XML 中的年龄 ID 绑定输入框。
        genderGroup = findViewById(R.id.gender_group); // 绑定单选组本身，读取的是组内被选按钮的 ID。
        genderError = findViewById(R.id.gender_error); // 绑定单选错误文字。
        genderGroup.setOnCheckedChangeListener((group, id) -> genderError.setVisibility(View.GONE)); // 一旦用户选择性别，隐藏先前的未选提示。
        registerForContextMenu(findViewById(R.id.bmi_icon)); // 注册图标的长按上下文菜单。
        viewModel = new ViewModelProvider(this).get(BmiViewModel.class); // 通过生命周期管理器取得或复用 ViewModel。
        viewModel.getResult().observe(this, result -> { // 注册观察者，根据状态驱动界面。
            if (result != null) { // 忽略表示已消费的空结果。
                showResult(result); // 将有效或带错误标记的结果交给渲染方法。
                viewModel.clearResult(); // 显示后清空本次事件。
            } // 结束当前代码块。
        }); // 结束回调并完成注册或提交。
        findViewById(R.id.calculate_button).setOnClickListener(view -> { // 绑定计算按钮，点击后读取当时的输入。
            heightInput.setError(null); // 清掉上一次身高错误，重新检查本次提交值。
            weightInput.setError(null); // 清掉上一次体重错误。
            ageInput.setError(null); // 清掉上一次年龄错误。
            genderError.setVisibility(View.GONE); // 清掉旧的性别提示，按本次选中状态重新决定是否显示。
            String height = heightInput.getText().toString(); // 读取厘米文本。
            String weight = weightInput.getText().toString(); // 读取千克文本。
            String age = ageInput.getText().toString(); // 读取年龄文本，稍后在模型中转整数。
            int selected = genderGroup.getCheckedRadioButtonId(); // 取得选中按钮的资源编号。
            String gender = selected == R.id.gender_male ? "Male" // 男选项映射成模型识别的固定字符串。
                    : selected == R.id.gender_female ? "Female" : ""; // 女选项映射为 Female，未选则传空串。
            viewModel.calculate(height, weight, age, gender); // 把表单内容交给 ViewModel。
        }); // 结束回调并完成注册或提交。
    } // 结束当前代码块。
    public void showResult(BmiResult result) { // 统一渲染计算结果，先检查字段错误。
        if (result.errorField != null) { // 有错误时保持在输入页。
            switch (result.errorField) { // 根据错误字段定位对应控件。
                case "height": heightInput.setError(getString(R.string.invalid_input)); break; // 在身高框显示错误后退出此分支。
                case "weight": weightInput.setError(getString(R.string.invalid_input)); break; // 在体重框显示错误后退出此分支。
                case "age": ageInput.setError(getString(R.string.invalid_age)); break; // 年龄框显示专用整数范围说明。
                case "gender": genderError.setVisibility(View.VISIBLE); break; // 未选性别时显示组旁的错误文字。
            } // 结束当前代码块。
            return; // 在此结束当前方法或回调。
        } // 结束当前代码块。
        Intent intent = new Intent(this, ReportActivity.class); // 构造显式 Intent，目标是本应用里的结果页。
        intent.putExtra("bmi", result.bmi); // 把算好的 BMI 传给报告页。
        intent.putExtra("age", result.age); // 传递年龄，供报告显示年龄组。
        intent.putExtra("gender", result.gender); // 传递性别供报告页本地化。
        intent.putExtra("category", result.category); // 传递分类标识供报告页选文字和样式。
        startActivity(intent); // 参数填齐后才打开结果页。
    } // 结束当前代码块。
    @Override // 覆盖父类或接口声明的方法。
    public boolean onCreateOptionsMenu(Menu menu) { // 系统请求构造顶栏菜单时进入。
        getMenuInflater().inflate(R.menu.menu_options, menu); // 把菜单资源中的条目加入当前菜单。
        return true; // 返回真，告知调用方本次处理成功。
    } // 结束当前代码块。
    @Override // 覆盖父类或接口声明的方法。
    public boolean onOptionsItemSelected(MenuItem item) { // 接收顶栏菜单点击事件。
        return handleMenu(item.getItemId()) || super.onOptionsItemSelected(item); // 共用处理方法优先，未处理时让父类接手。
    } // 结束当前代码块。
    @Override // 覆盖父类或接口声明的方法。
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo info) { // 系统构建长按菜单时回调。
        super.onCreateContextMenu(menu, view, info); // 先保留父类菜单行为。
        getMenuInflater().inflate(R.menu.menu_context, menu); // 加载长按菜单资源。
    } // 结束当前代码块。
    @Override // 覆盖父类或接口声明的方法。
    public boolean onContextItemSelected(MenuItem item) { // 接收长按菜单条目的点击。
        return handleMenu(item.getItemId()) || super.onContextItemSelected(item); // 共用处理方法未处理时交回父类。
    } // 结束当前代码块。
    private boolean handleMenu(int id) { // 集中用菜单条目编号识别操作。
        if (id == R.id.menu_about) { // 判断关于菜单。
            new AlertDialog.Builder(this).setTitle(R.string.about) // 建立带标题的关于对话框。
                    .setMessage(R.string.about_message).setPositiveButton(R.string.ok, null).show(); // 加入说明和关闭按钮后显示。
            return true; // 返回真，告知调用方本次处理成功。
        } // 结束当前代码块。
        if (id == R.id.menu_wiki) { // 判断是否打开百科链接。
            String language = getResources().getConfiguration().locale.getLanguage(); // 读取当前资源语言。
            String url = "zh".equals(language) ? "https://zh.wikipedia.org/wiki/身体质量指数" // 中文环境选择中文百科页面。
                    : "https://en.wikipedia.org/wiki/Body_mass_index"; // 其它语言选择英文百科页面。
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); // 交给系统可处理网页地址的应用打开。
            return true; // 返回真，告知调用方本次处理成功。
        } // 结束当前代码块。
        if (id == R.id.menu_exit) { // 判断退出操作。
            finish(); // 关闭当前页面，返回上一层。
            return true; // 返回真，告知调用方本次处理成功。
        } // 结束当前代码块。
        return false; // 没有匹配的菜单项，允许调用方继续处理。
    } // 结束当前代码块。
} // 结束当前代码块。
