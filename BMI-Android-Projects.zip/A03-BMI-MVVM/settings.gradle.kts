pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } } // 声明构建插件的下载仓库。
dependencyResolutionManagement { // 集中设置模块依赖解析规则。
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS) // 限制子模块单独配置仓库。
    repositories { google(); mavenCentral() } // 配置 Google 和 Maven 依赖仓库。
} // 结束当前构建配置块。
rootProject.name = "BMI-MVVM" // 设置工程显示名称。
include(":app") // 把应用模块纳入构建。
