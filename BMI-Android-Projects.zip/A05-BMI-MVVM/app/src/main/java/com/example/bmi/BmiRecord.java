package com.example.bmi; // 声明源码所在包，供同包类型引用。

public final class BmiRecord { // 将日期与 BMI 封装成不可变记录。
    public final String date; // 保存统一格式的日期文本。
    public final double bmi; // 记录原始 BMI 值。

    public BmiRecord(String date, double bmi) { // 用数据库读出的值初始化记录。
        this.date = date; // 写入日期成员。
        this.bmi = bmi; // 记录计算所得数值。
    } // 结束当前代码块。
} // 结束当前代码块。
