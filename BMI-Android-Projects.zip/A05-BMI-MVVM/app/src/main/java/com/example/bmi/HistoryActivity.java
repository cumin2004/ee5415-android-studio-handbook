package com.example.bmi; // 声明源码所在包，供同包类型引用。

import android.os.Bundle; // 引入 Bundle 类型供本文件使用。
import android.view.MenuItem; // 引入 MenuItem 类型供本文件使用。
import android.view.View; // 引入 View 类型供本文件使用。
import android.view.Gravity; // 引入 Gravity 类型供本文件使用。
import android.widget.LinearLayout; // 引入 LinearLayout 类型供本文件使用。
import android.widget.TextView; // 引入 TextView 类型供本文件使用。
import androidx.appcompat.app.AppCompatActivity; // 引入 AppCompatActivity 类型供本文件使用。
import java.text.SimpleDateFormat; // 引入 SimpleDateFormat 类型供本文件使用。
import java.util.Calendar; // 引入 Calendar 类型供本文件使用。
import java.util.List; // 引入 List 类型供本文件使用。
import java.util.Locale; // 引入 Locale 类型供本文件使用。

public class HistoryActivity extends AppCompatActivity { // 历史页管理月份切换、图形和表格。
    private final Calendar month = Calendar.getInstance(); // 日历对象代表当前正在浏览的月份。
    private BmiDatabase database; // 保存数据库访问对象。

    @Override // 覆盖父类或接口声明的方法。
    protected void onCreate(Bundle savedInstanceState) { // 页面创建时绑定布局和交互逻辑。
        super.onCreate(savedInstanceState); // 先交给父类初始化。
        setContentView(R.layout.activity_history); // 加载历史页 XML。
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true); // 存在操作栏时提供返回入口。
        month.set(Calendar.DAY_OF_MONTH, 1); // 统一从该月第一天计算查询边界。
        if (savedInstanceState != null) month.setTimeInMillis(savedInstanceState.getLong("month")); // 旋转重建时恢复原先查看的月份。
        database = new BmiDatabase(this); // 创建历史数据库帮助类实例。
        findViewById(R.id.previous_month).setOnClickListener(view -> { // 上个月按钮响应在这里注册。
            month.add(Calendar.MONTH, -1); // 日历后退一个月，允许跨年。
            refresh(); // 按更新后的月份重新查询并绘制。
        }); // 结束回调并完成注册或提交。
        findViewById(R.id.next_month).setOnClickListener(view -> { // 下个月按钮响应在这里注册。
            month.add(Calendar.MONTH, 1); // 日历前进一个月。
            refresh(); // 按更新后的月份重新查询并绘制。
        }); // 结束回调并完成注册或提交。
        refresh(); // 按更新后的月份重新查询并绘制。
    } // 结束当前代码块。

    private void refresh() { // 统一重建本月的标题、计数、图和表。
        List<BmiRecord> records = database.forMonth(month.get(Calendar.YEAR), month.get(Calendar.MONTH)); // 用日历中的年份、从零开始的月份查记录。
        ((TextView) findViewById(R.id.month_label)).setText( // 定位显示当前月份的标题控件。
                new SimpleDateFormat("yyyy-MM", Locale.US).format(month.getTime())); // 把月份格式化为年与两位数月份。
        ((TextView) findViewById(R.id.record_count)).setText(getString(R.string.records_count, records.size())); // 用查询条数填入数量文案。
        findViewById(R.id.empty_history).setVisibility(records.isEmpty() ? View.VISIBLE : View.GONE); // 当前月没有记录时显示空状态提示。
        ((BmiChartView) findViewById(R.id.bmi_chart)).setRecords(records, // 把查询出的记录交给图表。
                month.getActualMaximum(Calendar.DAY_OF_MONTH)); // 用本月实际天数作为横轴上界。
        LinearLayout table = findViewById(R.id.history_rows); // 定位容纳每行记录的竖排容器。
        table.removeAllViews(); // 清空旧月份的行，防止重复追加。
        addRow(table, getString(R.string.date_column), getString(R.string.bmi_column), true); // 先用本地化的列名建立表头。
        for (BmiRecord record : records) { // 逐条扫描月份内的记录。
            addRow(table, record.date, String.format(Locale.getDefault(), "%.2f", record.bmi), false); // 每条记录显示日期与两位小数的 BMI。
        } // 结束当前代码块。
    } // 结束当前代码块。

    private void addRow(LinearLayout table, String date, String bmi, boolean heading) { // 向表格添加一行，参数决定是否为表头。
        LinearLayout row = new LinearLayout(this); // 创建单行容器。
        row.setOrientation(LinearLayout.HORIZONTAL); // 两列采用水平方向排列。
        TextView dateText = new TextView(this); // 建立日期文本控件。
        TextView bmiText = new TextView(this); // 建立数值文本控件。
        dateText.setText(date); // 填入日期或日期列标题。
        bmiText.setText(bmi); // 填入 BMI 或数值列标题。
        dateText.setTextSize(16); // 设定日期文字大小。
        bmiText.setTextSize(16); // 设定数值文字大小。
        bmiText.setGravity(Gravity.END); // 将数值与对应列末端对齐。
        if (heading) { // 表头需要与数据行区分。
            dateText.setTypeface(null, android.graphics.Typeface.BOLD); // 把日期标题设为粗体。
            bmiText.setTypeface(null, android.graphics.Typeface.BOLD); // 把数值标题设为粗体。
        } // 结束当前代码块。
        int space = (int) (8 * getResources().getDisplayMetrics().density); // 把八个密度单位换算为像素。
        row.setPadding(0, space, 0, space); // 为该行添加上下间距。
        row.addView(dateText, new LinearLayout.LayoutParams(0, -2, 1)); // 让第一列按等份权重占用剩余空间。
        row.addView(bmiText, new LinearLayout.LayoutParams(0, -2, 1)); // 第二列使用相同权重。
        table.addView(row); // 把完整的一行加入历史表格。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    protected void onSaveInstanceState(Bundle state) { // 系统保存页面临时状态时回调。
        state.putLong("month", month.getTimeInMillis()); // 记录浏览月份，旋转后恢复。
        super.onSaveInstanceState(state); // 让父类保存其它界面状态。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    protected void onDestroy() { // 页面销毁时释放资源。
        database.close(); // 关闭该页面持有的数据库帮助类。
        super.onDestroy(); // 执行父类清理。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    public boolean onOptionsItemSelected(MenuItem item) { // 接收顶栏菜单点击事件。
        if (item.getItemId() == android.R.id.home) { // 检查操作栏的返回动作。
            finish(); // 关闭当前页面，返回上一层。
            return true; // 返回真，告知调用方本次处理成功。
        } // 结束当前代码块。
        return super.onOptionsItemSelected(item); // 其它条目回退给父类处理。
    } // 结束当前代码块。
} // 结束当前代码块。
