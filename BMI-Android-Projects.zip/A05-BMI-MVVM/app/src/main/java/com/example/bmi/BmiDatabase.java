package com.example.bmi; // 声明源码所在包，供同包类型引用。

import android.content.ContentValues; // 引入 ContentValues 类型供本文件使用。
import android.content.Context; // 引入 Context 类型供本文件使用。
import android.database.Cursor; // 引入 Cursor 类型供本文件使用。
import android.database.sqlite.SQLiteDatabase; // 引入 SQLiteDatabase 类型供本文件使用。
import android.database.sqlite.SQLiteOpenHelper; // 引入 SQLiteOpenHelper 类型供本文件使用。
import android.database.sqlite.SQLiteException; // 引入 SQLiteException 类型供本文件使用。
import java.text.SimpleDateFormat; // 引入 SimpleDateFormat 类型供本文件使用。
import java.util.ArrayList; // 引入 ArrayList 类型供本文件使用。
import java.util.Calendar; // 引入 Calendar 类型供本文件使用。
import java.util.List; // 引入 List 类型供本文件使用。
import java.util.Locale; // 引入 Locale 类型供本文件使用。

public class BmiDatabase extends SQLiteOpenHelper { // 用 SQLiteOpenHelper 管理 BMI 历史库。
    public BmiDatabase(Context context) { // 创建或打开应用的本地历史库。
        super(context, "bmi_history.db", null, 1); // 指定数据库名称和初始结构版本。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    public void onCreate(SQLiteDatabase db) { // 数据库首次建立时初始化表。
        db.execSQL("CREATE TABLE bmi_records (record_date TEXT PRIMARY KEY NOT NULL, " // 日期设为非空主键，使同日只能保留一条记录。
                + "bmi REAL NOT NULL CHECK(bmi > 0))"); // 用实数列保存 BMI，并要求数值大于零。
    } // 结束当前代码块。

    @Override // 覆盖父类或接口声明的方法。
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { } // 当前版本没有定义跨版本迁移步骤。

    public void save(String date, double bmi) { // 持久化指定日期的一次有效结果。
        ContentValues values = new ContentValues(); // 把列和值装入 ContentValues。
        values.put("record_date", date); // 写入日期主键。
        values.put("bmi", bmi); // 写入 BMI 数值。
        long row = getWritableDatabase().insertWithOnConflict("bmi_records", null, values, // 执行带主键冲突处理的插入。
                SQLiteDatabase.CONFLICT_REPLACE); // 若日期已存在，用本次值替换同日旧记录。
        if (row == -1) throw new SQLiteException("Could not save BMI record"); // 检查插入结果并报告失败。
    } // 结束当前代码块。

    public List<BmiRecord> forMonth(int year, int month) { // 按指定年月读取并排序。
        Calendar start = Calendar.getInstance(); // 准备计算月初边界。
        start.clear(); // 清掉当前时分秒等残留字段。
        start.set(year, month, 1); // 将日期设为传入月份的一号。
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.US); // 固定日期编码形式，使文本顺序与时间顺序一致。
        String from = format.format(start.getTime()); // 生成包含在查询内的起始日期。
        start.add(Calendar.MONTH, 1); // 推进一个月，跨年由 Calendar 处理。
        String until = format.format(start.getTime()); // 生成不包含在区间内的下一月月初。
        List<BmiRecord> records = new ArrayList<>(); // 用列表收集查询结果。
        try (Cursor cursor = getReadableDatabase().query("bmi_records", // 打开可读数据库并自动管理游标。
                new String[]{"record_date", "bmi"}, "record_date >= ? AND record_date < ?", // 只取日期及 BMI，条件为左闭右开的时间区间。
                new String[]{from, until}, null, null, "record_date ASC")) { // 绑定两个日期参数，并按日期升序排序。
            while (cursor.moveToNext()) records.add(new BmiRecord(cursor.getString(0), cursor.getDouble(1))); // 遍历游标，每行转换为一条类型化记录。
        } // 结束当前代码块。
        return records; // 把整月数据交给界面。
    } // 结束当前代码块。
} // 结束当前代码块。
