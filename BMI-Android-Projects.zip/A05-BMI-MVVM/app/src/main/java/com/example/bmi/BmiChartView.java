package com.example.bmi; // 声明源码所在包，供同包类型引用。

import android.content.Context; // 引入 Context 类型供本文件使用。
import android.graphics.Canvas; // 引入 Canvas 类型供本文件使用。
import android.graphics.Color; // 引入 Color 类型供本文件使用。
import android.graphics.Paint; // 引入 Paint 类型供本文件使用。
import android.util.AttributeSet; // 引入 AttributeSet 类型供本文件使用。
import android.view.View; // 引入 View 类型供本文件使用。
import java.util.ArrayList; // 引入 ArrayList 类型供本文件使用。
import java.util.List; // 引入 List 类型供本文件使用。
import java.util.Locale; // 引入 Locale 类型供本文件使用。

public class BmiChartView extends View { // 自定义 View，把一个月的 BMI 记录画成折线图。
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG); // 用抗锯齿画笔绘制线条和文字。
    private List<BmiRecord> records = new ArrayList<>(); // 初始数据为空列表。
    private int days = 31; // 保存本月天数用于计算横坐标。

    public BmiChartView(Context context, AttributeSet attrs) { // 布局从 XML 创建控件时调用此构造器。
        super(context, attrs); // 将上下文和 XML 属性交给父类解析。
    } // 结束当前代码块。

    public void setRecords(List<BmiRecord> values, int daysInMonth) { // 接收当前月份的数据及天数。
        records = new ArrayList<>(values); // 复制输入列表，避免调用者后续修改影响绘制。
        days = daysInMonth; // 记住月份长度。
        StringBuilder description = new StringBuilder("BMI"); // 开始构造读屏描述。
        for (BmiRecord record : records) description.append(String.format(Locale.getDefault(), // 按当前地区格式逐条追加记录。
                ", %s: %.2f", record.date, record.bmi)); // 在描述中列出日期和两位小数的数值。
        setContentDescription(description.toString()); // 为辅助功能提供整张图的文字替代。
        invalidate(); // 请求系统重新绘制控件。
    } // 结束当前代码块。

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; } // 把布局使用的密度单位转换为绘图使用的像素。

    @Override // 覆盖父类或接口声明的方法。
    protected void onDraw(Canvas canvas) { // 系统要求控件绘制时进入。
        super.onDraw(canvas); // 先执行父类的绘制逻辑。
        float left = dp(48), right = getWidth() - dp(18); // 给左侧刻度和右边界留出空间。
        float top = dp(28), bottom = getHeight() - dp(42); // 给图标题和横轴标签预留高度。
        if (right <= left || bottom <= top) return; // 可绘区域为空时结束绘制。
        double low = 18, high = 28; // 空数据时采用默认纵轴区间。
        if (!records.isEmpty()) { // 有记录时改用实际数据范围。
            low = records.get(0).bmi; // 从第一条记录初始化下界。
            high = low; // 初始上界与首条记录相同。
            for (BmiRecord record : records) { // 逐条扫描月份内的记录。
                low = Math.min(low, record.bmi); // 更新最小 BMI。
                high = Math.max(high, record.bmi); // 更新最大 BMI。
            } // 结束当前代码块。
            low = Math.floor(low - 1); // 在最小值下面留一个单位并向下取整。
            high = Math.ceil(high + 1); // 在最大值上方留白并向上取整。
        } // 结束当前代码块。
        paint.setTextSize(dp(12)); // 设置刻度文字尺寸。
        paint.setStrokeWidth(dp(1)); // 设置网格线宽度。
        for (int i = 0; i <= 4; i++) { // 五条水平刻度把区域分成四段。
            float y = bottom - (bottom - top) * i / 4; // 从数据刻度反算向下增长的屏幕纵坐标。
            paint.setColor(0xFFE0E0E0); // 设置浅灰网格色。
            canvas.drawLine(left, y, right, y, paint); // 画当前高度的水平参考线。
            paint.setColor(Color.DKGRAY); // 换深灰色标记坐标。
            paint.setTextAlign(Paint.Align.RIGHT); // 让纵轴标签向绘图区左边缘对齐。
            canvas.drawText(String.format(Locale.getDefault(), "%.1f", low + (high - low) * i / 4), // 用当前刻度对应的 BMI 值生成标签。
                    left - dp(8), y + dp(4), paint); // 把文字放到网格线左边。
        } // 结束当前代码块。
        paint.setColor(Color.DKGRAY); // 换深灰色标记坐标。
        canvas.drawLine(left, top, left, bottom, paint); // 画纵轴。
        canvas.drawLine(left, bottom, right, bottom, paint); // 画横轴。
        paint.setTextAlign(Paint.Align.CENTER); // 横轴日期以刻度位置为中心。
        for (int day : new int[]{1, 8, 15, 22, days}) { // 选出月初、周刻度和月底。
            float x = left + (right - left) * (day - 1) / (days - 1); // 把月内日期映射到左右边界之间的像素。
            canvas.drawText(Integer.toString(day), x, bottom + dp(18), paint); // 在对应横坐标下写日期。
        } // 结束当前代码块。
        canvas.drawText(getResources().getString(R.string.day_axis), (left + right) / 2, // 在横轴中心画轴说明。
                getHeight() - dp(4), paint); // 把轴说明放到控件底端。
        paint.setTextAlign(Paint.Align.LEFT); // 后续图题改用左对齐。
        canvas.drawText("BMI", left, dp(16), paint); // 在图顶标出纵轴含义。
        paint.setColor(0xFF3F51B5); // 切换为折线与数据点的颜色。
        paint.setStrokeWidth(dp(2)); // 设置折线宽度。
        float previousX = 0, previousY = 0; // 保存上一点的坐标用于连线。
        for (int i = 0; i < records.size(); i++) { // 按数据库排序逐条绘制数据。
            BmiRecord record = records.get(i); // 取得本次要画的日期与数值。
            int day = Integer.parseInt(record.date.substring(8)); // 从固定格式日期取出当月日号。
            float x = left + (right - left) * (day - 1) / (days - 1); // 把月内日期映射到左右边界之间的像素。
            float y = bottom - (float) ((record.bmi - low) / (high - low)) * (bottom - top); // 将 BMI 在数据范围中的占比映射为纵坐标。
            if (i > 0) canvas.drawLine(previousX, previousY, x, y, paint); // 从第二条数据起把相邻点连起来。
            canvas.drawCircle(x, y, dp(4), paint); // 画当前数据点。
            previousX = x; // 保存当前横坐标供下一轮连线。
            previousY = y; // 保存当前纵坐标供下一轮连线。
        } // 结束当前代码块。
    } // 结束当前代码块。
} // 结束当前代码块。
