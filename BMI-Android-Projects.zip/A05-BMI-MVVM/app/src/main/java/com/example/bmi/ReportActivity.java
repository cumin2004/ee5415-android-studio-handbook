package com.example.bmi; // 声明源码所在包，供同包类型引用。

import android.os.Bundle; // 引入 Bundle 类型供本文件使用。
import android.content.Intent; // 引入 Intent 类型供本文件使用。
import android.view.View; // 引入 View 类型供本文件使用。
import android.widget.TextView; // 引入 TextView 类型供本文件使用。
import androidx.appcompat.app.AppCompatActivity; // 引入 AppCompatActivity 类型供本文件使用。

public class ReportActivity extends AppCompatActivity { // 定义结果页，读取已经生成的计算结果。
    @Override // 覆盖父类或接口声明的方法。
    protected void onCreate(Bundle savedInstanceState) { // 页面创建时绑定布局和交互逻辑。
        super.onCreate(savedInstanceState); // 先交给父类初始化。
        setContentView(R.layout.activity_report); // 加载结果页 XML，之后才可依 ID 绑定结果控件。
        double bmi = getIntent().getDoubleExtra("bmi", 0); // 读取启动参数里的 BMI 数值。
        int age = getIntent().getIntExtra("age", 0); // 按 age 键读取 int 年龄。
        String gender = getIntent().getStringExtra("gender"); // 按 gender 键读字符串。该键和输入页对应。
        String category = getIntent().getStringExtra("category"); // 读取内部分类字符串。
        TextView result = findViewById(R.id.bmi_result); // 按布局 ID 找到用于显示 BMI 数字的控件。
        TextView categoryText = findViewById(R.id.bmi_category); // 找到用于显示分类名称的控件。
        result.setText(getString(R.string.bmi_value, bmi)); // 把 BMI 套入字符串资源中的两位小数占位符。
        ((TextView) findViewById(R.id.profile_summary)).setText(getString(R.string.profile_summary, // 用资源模板构造资料摘要。
                age, getString("Male".equals(gender) ? R.string.male : R.string.female))); // 显示年龄，并按当前语言显示性别文字。
        ((TextView) findViewById(R.id.age_group)).setText(age > 18 ? R.string.adult : R.string.child); // 十八岁以上显示成人组，否则显示非成人组。
        categoryText.setText(categoryResource(category)); // 将内部分类映射为当前语言的字符串资源。
        if (BmiCalculator.isSevere(category)) { // 判断结果是否进入严重提示分支。
            findViewById(R.id.bmi_note).setVisibility(View.VISIBLE); // 让原本隐藏的警告文字可见。
            result.setTextColor(0xFFB71C1C); // 把数值改为警告色。
            categoryText.setTextColor(0xFFB71C1C); // 分类名称也使用相同的警告色。
        } // 结束当前代码块。
        findViewById(R.id.history_button).setOnClickListener(view -> // 监听历史按钮的点击。
                startActivity(new Intent(this, HistoryActivity.class))); // 显式打开历史页。
        findViewById(R.id.back_button).setOnClickListener(view -> finish()); // 点击返回时关闭当前详情页，回到原来的输入页。
    } // 结束当前代码块。
    private int categoryResource(String category) { // 把不随语言变化的分类转成字符串资源编号。
        switch (category) { // 按分类标识选择资源。
            case "Underweight": return R.string.underweight; // 选择偏低类别的本地化文案。
            case "Normal range": return R.string.normal; // 选择正常类别的本地化文案。
            case "Overweight": return R.string.overweight; // 选择超重类别的本地化文案。
            case "Obese": return R.string.obese; // 选择肥胖类别的本地化文案。
            case "Acceptable Weight": return R.string.acceptable; // 选择儿童可接受范围的文案。
            case "Severely Underweight": return R.string.severe_underweight; // 选择严重偏低类别文案。
            case "Severely Overweight": return R.string.severe_overweight; // 选择严重超重类别文案。
            default: throw new IllegalArgumentException("Unknown BMI category"); // 未知分类属于程序数据错误，抛出异常。
        } // 结束当前代码块。
    } // 结束当前代码块。
} // 结束当前代码块。
