package com.example.bmi; // 指定包名。它要和项目命名空间及该文件的目录对应。

import android.app.Activity; // 使用系统的 Activity 作为输入页面基类。
import android.content.Intent; // 使用 Intent 指定结果页并携带输入参数。
import android.os.Bundle; // 使用 Bundle 接收安卓传给页面的启动或恢复状态。
import android.view.View; // 使用 View 中的可见性常量控制错误文字。
import android.widget.EditText; // 使用 EditText 读身高、体重和年龄。
import android.widget.RadioGroup; // 使用 RadioGroup 让性别选项互斥。
import android.widget.TextView; // 使用 TextView 显示尚未选择性别的提示。

public class MainActivity extends Activity { // 定义输入页面。它负责接收和校验输入，随后打开结果页。
    private EditText heightInput; // 持有身高输入框，约定其单位为厘米。
    private EditText weightInput; // 持有体重输入框，约定其单位为千克。
    private EditText ageInput; // 持有年龄输入框，要求整岁。
    private RadioGroup genderGroup; // 持有性别单选组，便于读取当前选中的按钮。
    private TextView genderError; // 持有性别错误提示文字，未选时显示。

    @Override // 标明下面的方法覆盖系统生命周期方法。
    protected void onCreate(Bundle savedInstanceState) { // 系统创建页面时进入这里。
        super.onCreate(savedInstanceState); // 先让父类完成页面初始化。
        setContentView(R.layout.activity_main); // 加载主页面布局。控件必须等布局加载后才能查找。
        heightInput = findViewById(R.id.height_input); // 用 XML 中的身高 ID 绑定输入框。
        weightInput = findViewById(R.id.weight_input); // 用 XML 中的体重 ID 绑定输入框。
        ageInput = findViewById(R.id.age_input); // 用 XML 中的年龄 ID 绑定输入框。
        genderGroup = findViewById(R.id.gender_group); // 绑定单选组本身，读取的是组内被选按钮的 ID。
        genderError = findViewById(R.id.gender_error); // 绑定单选错误文字。
        genderGroup.setOnCheckedChangeListener((group, checkedId) -> genderError.setVisibility(View.GONE)); // 选项变化后隐藏未选择的错误提示。
        findViewById(R.id.calculate_button).setOnClickListener(view -> showReport()); // 找到计算按钮并注册事件，点击后才校验和跳转。
    } // 结束页面初始化。

    private Integer readAge() { // 返回包装类型，以便用空值标记年龄无效。
        try { // 把文本转整数及数值范围检查放在同一个异常处理里。
            int age = Integer.parseInt(ageInput.getText().toString().trim()); // 读取文字，去除首尾空白，再转成整数。
            BmiCalculator.isAdult(age); // 复用计算类里的年龄范围校验。此处只需要检查，不使用它的布尔结果。
            return age; // 校验通过就返回整岁。
        } catch (IllegalArgumentException invalid) { // 格式不对或超范围会抛出此类异常，并进入同样的提示分支。
            ageInput.setError(getString(R.string.invalid_age)); // 从字符串资源取错误文案，显示在年龄框上。
            return null; // 把空值返回给调用方，阻止跳转。
        } // 结束年龄错误处理。
    } // 结束年龄读取方法。

    private Double readPositiveNumber(EditText input) { // 接收任何数字输入框，复用同一套正数校验。
        try { // 尝试把文本解析成小数。
            double number = Double.parseDouble(input.getText().toString().trim()); // 先取当前文字并去空白，再用双精度类型解析。
            if (number > 0 && !Double.isInfinite(number)) return number; // 只接受大于零的有限数。非数字值不会通过大于零的判断。
        } catch (NumberFormatException ignored) { } // 文本不能解析时，继续执行下面统一的错误提示。
        input.setError(getString(R.string.invalid_input)); // 在对应输入框显示非正数或非法输入提示。
        return null; // 用空值通知调用方这个字段无效。
    } // 结束通用数字读取方法。

    private void showReport() { // 计算按钮入口，集中处理校验、打包参数和页面跳转。
        heightInput.setError(null); // 清掉上一次身高错误，重新检查本次提交值。
        weightInput.setError(null); // 清掉上一次体重错误。
        ageInput.setError(null); // 清掉上一次年龄错误。
        genderError.setVisibility(View.GONE); // 清掉旧的性别提示，按本次选中状态重新决定是否显示。
        Double height = readPositiveNumber(heightInput); // 使用通用方法读取身高。
        Double weight = readPositiveNumber(weightInput); // 对体重复用同一方法。
        Integer age = readAge(); // 使用专用方法读取整数年龄。
        int checkedGender = genderGroup.getCheckedRadioButtonId(); // 取得被选按钮的资源 ID。无选项时本组返回负一。
        if (checkedGender == -1) genderError.setVisibility(View.VISIBLE); // 没有选项时显示单独的性别错误文字。
        if (height == null || weight == null || age == null || checkedGender == -1) return; // 任一项无效就返回，避免空值被拆箱或错误参数进入详情页。
        String gender = checkedGender == R.id.gender_male ? "Male" : "Female"; // 将单选按钮的 ID 转成结果页和计算类共用的字符串。
        try { // 跳转之前先验证这组身高体重能否得到有效的计算结果。
            BmiCalculator.calculate(height, weight); // 调用计算类，也覆盖极端数值引起的上溢或下溢。
        } catch (IllegalArgumentException invalid) { // 参数超出计算支持范围时，在输入页处理。
            heightInput.setError(getString(R.string.invalid_input)); // 本项目把这类计算错误显示在身高框。
            return; // 有计算错误时留在输入页。
        } // 结束结果范围检查。
        Intent intent = new Intent(this, ReportActivity.class); // 构造显式 Intent，目标是本应用里的结果页。
        intent.putExtra("height", height.doubleValue()); // 以 height 为键传 double，详情页必须用相同键和类型取值。
        intent.putExtra("weight", weight.doubleValue()); // 以 weight 为键传 double。
        intent.putExtra("age", age.intValue()); // 以 age 为键传 int。
        intent.putExtra("gender", gender); // 以 gender 为键传字符串。
        startActivity(intent); // 参数填齐后才打开结果页。
    } // 结束计算按钮流程。
} // 结束输入页面类。
