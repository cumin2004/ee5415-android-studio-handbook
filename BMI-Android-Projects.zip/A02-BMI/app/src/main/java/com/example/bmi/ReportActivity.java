package com.example.bmi; // 使用与输入页、计算类相同的包。

import android.app.Activity; // 使用系统 Activity 作为详情页基类。
import android.graphics.Color; // 用 Color 把颜色字符串解析为文字颜色。
import android.os.Bundle; // 用 Bundle 接收系统传给页面的状态。
import android.view.View; // 用 View 控制提示文字是否占用布局空间。
import android.widget.LinearLayout; // 用 LinearLayout 引用结果卡片容器。
import android.widget.TextView; // 用 TextView 读取和更新结果页文字。

public class ReportActivity extends Activity { // 定义该应用的第二个页面。
    @Override // 标明下面覆盖安卓的生命周期方法。
    protected void onCreate(Bundle savedInstanceState) { // 结果页创建时进入这里，读取参数并展示。
        super.onCreate(savedInstanceState); // 先交给父类初始化。
        setContentView(R.layout.activity_report); // 加载结果页 XML，之后才可依 ID 绑定结果控件。
        double height = getIntent().getDoubleExtra("height", 0); // 按 height 键读取 double 身高，缺失时返回零交给校验。
        double weight = getIntent().getDoubleExtra("weight", 0); // 按 weight 键读取 double 体重，同样用零作为缺失默认值。
        int age = getIntent().getIntExtra("age", 0); // 按 age 键读取 int 年龄。
        String gender = getIntent().getStringExtra("gender"); // 按 gender 键读字符串。该键和输入页对应。
        double bmi; // 留出计算值变量，供后面格式化显示。
        String category; // 留出分类文字变量，供界面和警告分支使用。
        boolean adult; // 留出成人标志，供选择分类函数和显示用户资料使用。
        try { // 一起处理数据计算、年龄校验及分类中的异常。
            bmi = BmiCalculator.calculate(height, weight); // 复用同一计算方法得到原始 BMI。
            adult = BmiCalculator.isAdult(age); // 确定走成人还是非成人分类，顺便校验年龄。
            category = adult // 按成人标志从两种分类函数选一种。
                    ? BmiCalculator.adultCategory(bmi) // 成人分支只按 BMI 数值判断。
                    : BmiCalculator.childCategory(bmi, age, gender); // 非成人分支还按年龄与性别查表。
        } catch (IllegalArgumentException invalid) { // 捕获非法来源或超范围参数。
            finish(); // 关闭无法正确呈现数据的详情页。
            return; // 立即中止方法，避免继续更新界面。
        } // 结束详情页数据校验。
        TextView result = findViewById(R.id.bmi_result); // 按布局 ID 找到用于显示 BMI 数字的控件。
        result.setText(getString(R.string.bmi_value, bmi)); // 把 BMI 套入字符串资源中的两位小数占位符。
        TextView profile = findViewById(R.id.profile_summary); // 按布局 ID 找到显示年龄、性别和组别的文字。
        profile.setText(getString(R.string.profile_summary, age, // 准备把年龄等三个参数传给格式化资源。
                gender == null ? "" : gender, getString(adult ? R.string.adult : R.string.child))); // 空性别显示为空，成人标志则决定组别文案。
        TextView categoryText = findViewById(R.id.bmi_category); // 找到用于显示分类名称的控件。
        categoryText.setText(category); // 把计算类返回的英文分类显示在界面上。
        TextView note = findViewById(R.id.bmi_note); // 找到用于显示严重提示的控件。
        LinearLayout card = findViewById(R.id.result_card); // 找到可以替换背景的结果卡片容器。
        boolean severe = BmiCalculator.isSevere(category); // 用计算类判定是否需要警告样式。
        if (severe) { // 只有严重分类才执行下面的样式更新。
            card.setBackgroundResource(R.drawable.result_card_warning); // 把默认卡片背景换成警告背景资源。
            result.setTextColor(Color.parseColor("#B91C1C")); // 把 BMI 数字显示为较深的红色。
            categoryText.setTextColor(Color.parseColor("#991B1B")); // 把分类名称也显示为红色。
            note.setText(category.equals("Severely Underweight") // 根据当前严重分类，从两个警告资源中选一个。
                    ? R.string.severe_underweight_warning // 严重偏低使用对应的警告文案。
                    : R.string.severe_overweight_warning); // 其它严重情况用严重偏高警告文案。
            note.setTextColor(Color.parseColor("#991B1B")); // 应用红色提示文字样式。
        } else { // 进入不需要警告的分支。
            note.setVisibility(View.GONE); // 隐藏警告控件，并移除它占用的空间。
        } // 结束警告样式判断。
        findViewById(R.id.back_button).setOnClickListener(view -> finish()); // 点击返回时关闭当前详情页，回到原来的输入页。
    } // 结束结果页创建和展示流程。
} // 结束报告页面类。
