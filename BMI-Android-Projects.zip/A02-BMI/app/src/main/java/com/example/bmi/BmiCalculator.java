package com.example.bmi; // 使用与两个 Activity 相同的包，让它们可以引用本类。

public final class BmiCalculator { // 定义只处理计算规则的工具类，界面代码放在 Activity 中。
    private static final double[][] BOYS = { // 定义男生查表数据。每行对应一岁，每列是一个分类上界。
            {12.8, 13.1, 18.8, 21.4}, // 6 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {13.0, 13.3, 19.8, 23.0}, // 7 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {13.2, 13.6, 20.9, 24.6}, // 8 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {13.5, 13.8, 21.8, 26.0}, // 9 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {13.8, 14.1, 22.7, 27.3}, // 10 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {14.1, 14.5, 23.6, 28.3}, // 11 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {14.4, 14.8, 24.3, 29.2}, // 12 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {14.7, 15.1, 25.0, 30.0}, // 13 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.0, 15.4, 25.5, 30.6}, // 14 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.3, 15.8, 26.1, 31.2}, // 15 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.6, 16.1, 26.5, 31.7}, // 16 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.9, 16.3, 27.0, 32.1}, // 17 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {16.1, 16.6, 27.4, 32.4} // 18 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
    }; // 结束男生查表数据。

    private static final double[][] GIRLS = { // 定义女生查表数据，结构与男生表相同。
            {12.6, 12.8, 18.3, 20.5}, // 6 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {12.8, 13.1, 19.1, 21.8}, // 7 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {13.1, 13.4, 20.1, 23.1}, // 8 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {13.4, 13.7, 21.0, 24.4}, // 9 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {13.7, 14.1, 21.9, 25.6}, // 10 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {14.1, 14.4, 22.7, 26.6}, // 11 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {14.4, 14.8, 23.4, 27.5}, // 12 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {14.8, 15.2, 24.0, 28.3}, // 13 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.1, 15.5, 24.6, 28.9}, // 14 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.4, 15.8, 25.0, 29.4}, // 15 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.7, 16.1, 25.4, 29.7}, // 16 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {15.9, 16.3, 25.7, 30.0}, // 17 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
            {16.1, 16.5, 25.9, 30.3} // 18 岁的一行。四列依次是严重偏低、偏低、可接受和超重各区间的上界。
    }; // 结束女生查表数据。

    private BmiCalculator() { } // 禁止创建工具类对象，外部直接调用静态方法。

    public static double calculate(double heightCm, double weightKg) { // 接收厘米和千克，返回未格式化的 BMI 数值。
        if (!(heightCm > 0) || !(weightKg > 0) // 检查身高体重是否都为正，非数字也不能通过。
                || Double.isInfinite(heightCm) || Double.isInfinite(weightKg)) { // 同时排除正无穷，避免其进入换算。
            throw new IllegalArgumentException("Height and weight must be finite and positive"); // 用参数异常让调用方决定怎样提示。
        } // 结束输入范围检查。
        double heightM = heightCm / 100.0; // 将厘米除以一百，换成公式所需的米。
        double bmi = weightKg / (heightM * heightM); // 体重除以身高米数的平方，得到原始 BMI。
        if (!(bmi > 0) || Double.isInfinite(bmi)) { // 再校验计算结果，处理极端输入导致的数值异常。
            throw new IllegalArgumentException("Values are outside the supported range"); // 抛出范围错误，交给调用页面处理。
        } // 结束输出范围检查。
        return bmi; // 返回原始数值，显示时再格式化。
    } // 结束 BMI 计算方法。

    public static boolean isAdult(int age) { // 按作业规则验证年龄，合法时返回是否走成人分支。
        if (age < 6 || age > 120) { // 只接受六至一百二十周岁，包含两个端点。
            throw new IllegalArgumentException("Age must be from 6 to 120"); // 拒绝超出范围的整岁输入。
        } // 结束范围校验。
        return age > 18; // 十八岁仍走非成人分支，十九岁开始走成人分支。
    } // 结束年龄判断方法。

    public static String adultCategory(double bmi) { // 按作业规定的成人阈值，给原始 BMI 分类。
        if (!(bmi > 0) || Double.isInfinite(bmi)) { // 分类前检查 BMI 是有意义的有限正数。
            throw new IllegalArgumentException("BMI must be finite and positive"); // 无效值不能进入分类分支。
        } // 结束分类前校验。
        if (bmi < 18.5) return "Underweight"; // 严格小于十八点五走体重偏低类别。
        if (bmi < 23.0) return "Normal range"; // 前面的分支已排除低值，此处分段包含十八点五，不含二十三。
        if (bmi < 25.0) return "Overweight"; // 此处分段包含二十三，不含二十五。
        return "Obese"; // 剩下的有效值都大于或等于二十五。
    } // 结束成人分类方法。

    public static String childCategory(double bmi, int age, String gender) { // 按非成人年龄和性别查表，再用作业规定的四个上界分类。
        if (age < 6 || age > 18) { // 先保护数组索引，只接受六至十八岁。
            throw new IllegalArgumentException("Child age must be from 6 to 18"); // 用参数异常表示年龄无法查表。
        } // 结束查表年龄检查。
        double[][] chart; // 声明本次分类使用的阈值表。
        if ("Male".equals(gender)) { // 用常量字符串调用相等比较，即使传入空值也不会抛空指针。
            chart = BOYS; // 选男生阈值表。
        } else if ("Female".equals(gender)) { // 次选女生对应的字符串。
            chart = GIRLS; // 选女生阈值表。
        } else { // 其它字符串无法选择图表。
            throw new IllegalArgumentException("Gender must be Male or Female"); // 抛出参数异常通知调用方。
        } // 结束查表选择。
        double value = Math.round(bmi * 10.0) / 10.0; // 按原作业规则先把 BMI 舍入到一位小数再查表。
        double[] row = chart[age - 6]; // 表的首行对应六岁，因此年龄减六得到下标。
        if (value <= row[0]) return "Severely Underweight"; // 不超过第一列上界，归入严重偏低类别。
        if (value <= row[1]) return "Underweight"; // 上一个分支已排除第一段，此处包含第二列上界。
        if (value <= row[2]) return "Acceptable Weight"; // 第三个区间包含正常范围的上界。
        if (value <= row[3]) return "Overweight"; // 第四个区间包含超重一段的上界。
        return "Severely Overweight"; // 大于第四列上界，归入严重超重类别。
    } // 结束非成人分类方法。

    public static boolean isSevere(String category) { // 判断当前分类是否需要显示特殊样式与提示。
        return "Severely Underweight".equals(category) // 严重偏低需要提示。
                || "Severely Overweight".equals(category); // 严重超重也需要提示，其他分类返回假。
    } // 结束严重程度检测。
} // 结束计算工具类。
