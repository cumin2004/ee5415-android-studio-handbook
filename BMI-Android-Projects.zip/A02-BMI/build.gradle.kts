plugins { id("com.android.application") version "9.4.0" apply false } // 应用或声明 Android 构建插件。
