package com.example.bmi; // 声明源码所在包，供同包类型引用。
public class BmiModel { // 封装表单校验和 BMI 计算，界面只处理返回值。
    public BmiResult calculate(String heightText, String weightText, String ageText, String gender) { // 把表单文本转换为带数值或错误字段的结果对象。
        double height, weight; // 预留解析后的身高和体重。
        int age; // 年龄要求整岁，因此使用整数。
        try { // 在这里执行可能抛出异常的操作。
            height = Double.parseDouble(heightText.trim()); // 清除前后空白后解析身高。
            if (!(height > 0) || Double.isInfinite(height)) return BmiResult.error("height"); // 拒绝非正数、无穷及非数字值，标记身高字段。
        } catch (NumberFormatException e) { return BmiResult.error("height"); } // 解析失败直接返回身高错误。
        try { // 在这里执行可能抛出异常的操作。
            weight = Double.parseDouble(weightText.trim()); // 把体重文本转为小数。
            if (!(weight > 0) || Double.isInfinite(weight)) return BmiResult.error("weight"); // 验证体重是有限正数。
        } catch (NumberFormatException e) { return BmiResult.error("weight"); } // 无法解析时只标记体重字段。
        try { // 在这里执行可能抛出异常的操作。
            age = Integer.parseInt(ageText.trim()); // 把年龄解析为整数。
            BmiCalculator.isAdult(age); // 复用计算类里的年龄范围校验。此处只需要检查，不使用它的布尔结果。
        } catch (IllegalArgumentException e) { return BmiResult.error("age"); } // 捕获整数格式错误和超范围年龄。
        if (!"Male".equals(gender) && !"Female".equals(gender)) return BmiResult.error("gender"); // 性别字段只接受单选按钮对应的两个内部值。
        try { // 在这里执行可能抛出异常的操作。
            double bmi = BmiCalculator.calculate(height, weight); // 复用公共公式，输入厘米和千克。
            String category = BmiCalculator.isAdult(age) // 根据年龄选择下面的成人或儿童分支。
                    ? BmiCalculator.adultCategory(bmi) // 成人分支只按 BMI 数值判断。
                    : BmiCalculator.childCategory(bmi, age, gender); // 非成人分支还按年龄与性别查表。
            return new BmiResult(bmi, age, gender, category, null); // 成功结果包含数值与分类，错误字段留空。
        } catch (IllegalArgumentException e) { return BmiResult.error("height"); } // 底层公式拒绝非法参数时返回身高错误标记。
    } // 结束当前代码块。
} // 结束当前代码块。
