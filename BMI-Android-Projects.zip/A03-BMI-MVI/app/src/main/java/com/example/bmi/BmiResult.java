package com.example.bmi; // 声明源码所在包，供同包类型引用。
public final class BmiResult { // 定义在计算层和界面之间传递的结果对象。
    public final double bmi; // 记录原始 BMI 值。
    public final int age; // 保留整岁供报告显示。
    public final String gender; // 保留性别作为页面参数。
    public final String category; // 保存计算类返回的分类标识。
    public final String errorField; // 校验失败时指出哪个输入控件需要显示提示。
    public BmiResult(double bmi, int age, String gender, String category, String errorField) { // 统一初始化成功和失败两种结果。
        this.bmi = bmi; // 记录计算所得数值。
        this.age = age; // 记录本次计算的年龄。
        this.gender = gender; // 记录本次计算的性别。
        this.category = category; // 记录分类结果。
        this.errorField = errorField; // 记录可能的错误字段。
    } // 结束当前代码块。
    public static BmiResult error(String field) { // 提供创建失败结果的入口。
        return new BmiResult(0, 0, "", "", field); // 其它字段使用占位值，界面应先判断错误字段。
    } // 结束当前代码块。
} // 结束当前代码块。
