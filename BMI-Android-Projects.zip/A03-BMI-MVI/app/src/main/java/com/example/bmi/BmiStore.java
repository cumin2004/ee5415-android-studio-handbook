package com.example.bmi; // 声明源码所在包，供同包类型引用。

import androidx.lifecycle.LiveData; // 引入 LiveData 类型供本文件使用。
import androidx.lifecycle.MutableLiveData; // 引入 MutableLiveData 类型供本文件使用。
import androidx.lifecycle.ViewModel; // 引入 ViewModel 类型供本文件使用。

public class BmiStore extends ViewModel { // 用 ViewModel 承载 MVI 的状态和事件处理。
    private final BmiModel model = new BmiModel(); // 持有负责校验与计算的模型。
    private final MutableLiveData<BmiState> state = new MutableLiveData<>(new BmiState(null)); // 以空结果初始化状态流。
    public LiveData<BmiState> getState() { return state; } // 向观察者暴露只读的状态接口。
    public void dispatch(BmiIntent intent) { state.setValue(reduce(intent)); } // 接收事件，先归约再发布新状态。
    private BmiState reduce(BmiIntent intent) { // 把用户事件变换为下一个状态。
        if (intent instanceof BmiIntent.Calculate) { // 判断是否为请求计算的事件。
            BmiIntent.Calculate input = (BmiIntent.Calculate) intent; // 转换成计算事件以读取四个字段。
            return new BmiState(model.calculate(input.height, input.weight, input.age, input.gender)); // 调用模型，用返回的结果创建状态。
        } // 结束当前代码块。
        return new BmiState(null); // 清空已消费的结果，防止重复跳转。
    } // 结束当前代码块。
} // 结束当前代码块。
