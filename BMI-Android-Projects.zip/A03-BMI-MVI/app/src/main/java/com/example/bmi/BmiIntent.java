package com.example.bmi; // 声明源码所在包，供同包类型引用。
public abstract class BmiIntent { // 定义用户操作的抽象类型，Store 通过子类型识别事件。
    public static final class Calculate extends BmiIntent { // 计算事件携带提交时的四项原始输入。
        public final String height, weight, age, gender; // 用不可重新赋值的字段保存一次输入快照。
        public Calculate(String height, String weight, String age, String gender) { // 从页面接收身高、体重、年龄及性别字符串。
            this.height = height; this.weight = weight; this.age = age; this.gender = gender; // 逐项保存事件参数，交给归约函数处理。
        } // 结束当前代码块。
    } // 结束当前代码块。
    public static final class ReportShown extends BmiIntent { } // 报告显示完毕后派发此事件，消耗已处理的结果。
} // 结束当前代码块。
