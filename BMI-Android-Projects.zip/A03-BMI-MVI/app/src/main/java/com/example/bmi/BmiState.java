package com.example.bmi; // 声明源码所在包，供同包类型引用。
public final class BmiState { // 把本轮结果包装为可观察的界面状态。
    public final BmiResult result; // 空结果表示当前没有待处理的报告。
    public BmiState(BmiResult result) { this.result = result; } // 创建新状态时固定本轮结果。
} // 结束当前代码块。
