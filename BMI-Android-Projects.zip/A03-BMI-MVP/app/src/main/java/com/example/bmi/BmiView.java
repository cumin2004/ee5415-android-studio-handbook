package com.example.bmi; // 声明源码所在包，供同包类型引用。
public interface BmiView { void showResult(BmiResult result); } // 定义视图必须实现的结果展示契约。
