package com.example.bmi; // 声明源码所在包，供同包类型引用。
public class BmiPresenter { // Presenter 协调输入、计算和界面回调。
    private final BmiView view; // 通过视图接口通知界面，降低与 Activity 的耦合。
    private final BmiModel model; // 持有负责计算的模型。
    public BmiPresenter(BmiView view, BmiModel model) { this.view = view; this.model = model; } // 构造时注入当前视图和模型。
    public void calculate(String height, String weight, String age, String gender) { // 接收页面交来的原始表单数据。
        view.showResult(model.calculate(height, weight, age, gender)); // 先由模型计算，再回调视图显示结果。
    } // 结束当前代码块。
} // 结束当前代码块。
